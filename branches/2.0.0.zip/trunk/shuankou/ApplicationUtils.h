//
//  ApplicationUtils.h
//  zggqt
//
//  Created by Leo on 13-6-9.
//  Copyright (c) 2013年 Maitianer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplicationUtils : NSObject

+ (void)MsgBox:(NSString *)msgStr;
+ (NSString *)formatNumber:(float)num;
@end
