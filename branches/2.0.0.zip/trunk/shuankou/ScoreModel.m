//
//  ScoreModel.m
//  shuankou
//
//  Created by 金邦铄 on 14-5-23.
//  Copyright (c) 2014年 金邦铄. All rights reserved.
//

#import "ScoreModel.h"

@implementation ScoreModel

@end
